# player_fixed.py
import sys
import os
import random
import pygame
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QPushButton, 
                             QSlider, QLabel, QFileDialog, QHBoxLayout, 
                             QVBoxLayout, QListWidget, QListWidgetItem, QMenu)
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QIcon, QColor, QAction
from mutagen.mp3 import MP3
from mutagen.wave import WAVE

class QiwzyPlayer(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('qiwzy-player')
        self.setGeometry(100, 100, 900, 600)
        self.setStyleSheet('background-color: #1e1e1e; color: white;')
        
        # Устанавливаем иконку
        self.setWindowIcon(QIcon(self.resource_path('icon.ico')))
        
        # Инициализируем pygame ДО создания UI
        pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=4096)
        
        self.playlist = []
        self.current_index = -1
        self.track_length = 0
        self.current_pos = 0
        self.is_paused = False
        self.slider_being_moved = False
        self.repeat_playlist = False
        self.repeat_track = False
        self.shuffle_mode = False
        
        # Timer для обновления интерфейса
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_slider)
        self.timer.start(100)
        
        self.init_ui()

    def resource_path(self, relative_path):
        """Получает правильный путь для ресурсов после упаковки в exe"""
        try:
            base_path = sys._MEIPASS
        except Exception:
            base_path = os.path.abspath(".")
        return os.path.join(base_path, relative_path)

    def init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Track info
        self.track_label = QLabel('No track loaded')
        self.track_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.track_label.setStyleSheet('font-size: 22px; font-weight: bold; margin: 10px;')
        
        # Playlist display
        self.playlist_widget = QListWidget()
        self.playlist_widget.setStyleSheet('''
            QListWidget {
                background-color: #2d2d2d;
                border: 1px solid #444;
                border-radius: 5px;
                font-size: 14px;
            }
            QListWidget::item {
                padding: 8px;
                border-bottom: 1px solid #444;
            }
            QListWidget::item:selected {
                background-color: #ff6600;
                color: white;
            }
        ''')
        self.playlist_widget.itemDoubleClicked.connect(self.play_selected_track)
        self.playlist_widget.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.playlist_widget.customContextMenuRequested.connect(self.show_context_menu)
        
        # Control buttons
        self.play_button = QPushButton('▶')
        self.play_button.clicked.connect(self.play_pause)
        self.style_button(self.play_button, 'circle')
        
        self.stop_button = QPushButton('■')
        self.stop_button.clicked.connect(self.stop)
        self.style_button(self.stop_button, 'square')
        
        self.prev_button = QPushButton('⏮')
        self.prev_button.clicked.connect(self.prev_track)
        self.style_button(self.prev_button, 'rounded')
        
        self.next_button = QPushButton('⏭')
        self.next_button.clicked.connect(self.next_track)
        self.style_button(self.next_button, 'rounded')
        
        # Repeat and shuffle buttons
        self.repeat_playlist_button = QPushButton('🔁')
        self.repeat_playlist_button.setCheckable(True)
        self.repeat_playlist_button.clicked.connect(self.toggle_repeat_playlist)
        self.style_button(self.repeat_playlist_button, 'rounded')
        
        self.repeat_track_button = QPushButton('🔂')
        self.repeat_track_button.setCheckable(True)
        self.repeat_track_button.clicked.connect(self.toggle_repeat_track)
        self.style_button(self.repeat_track_button, 'rounded')
        
        self.shuffle_button = QPushButton('🔀')
        self.shuffle_button.setCheckable(True)
        self.shuffle_button.clicked.connect(self.toggle_shuffle)
        self.style_button(self.shuffle_button, 'rounded')
        
        # Time slider (РАБОЧАЯ ПЕРЕМОТКА)
        self.time_slider = QSlider(Qt.Orientation.Horizontal)
        self.time_slider.setRange(0, 1000)
        self.time_slider.sliderPressed.connect(self.slider_pressed)
        self.time_slider.sliderReleased.connect(self.slider_released)
        self.time_slider.sliderMoved.connect(self.slider_moved)
        self.time_slider.setStyleSheet('''
            QSlider::handle:horizontal {
                background: #ff6600;
                width: 14px;
                border-radius: 7px;
            }
            QSlider::groove:horizontal {
                background: #555;
                height: 6px;
                border-radius: 3px;
            }
            QSlider::sub-page:horizontal {
                background: #ff6600;
                border-radius: 3px;
            }
        ''')
        
        # Time labels
        self.current_time_label = QLabel('00:00')
        self.total_time_label = QLabel('00:00')
        
        # Volume control
        self.volume_slider = QSlider(Qt.Orientation.Horizontal)
        self.volume_slider.setRange(0, 100)
        self.volume_slider.setValue(70)
        self.volume_slider.valueChanged.connect(self.change_volume)
        self.volume_slider.setStyleSheet('''
            QSlider::handle:horizontal {
                background: #ff6600;
                width: 12px;
                border-radius: 6px;
            }
            QSlider::groove:horizontal {
                background: #555;
                height: 6px;
                border-radius: 3px;
            }
            QSlider::sub-page:horizontal {
                background: #ff6600;
                border-radius: 3px;
            }
        ''')
        self.volume_label = QLabel('Volume')
        
        # File loading buttons
        self.load_button = QPushButton('Load Tracks')
        self.load_button.clicked.connect(self.load_files)
        self.load_folder_button = QPushButton('Load Folder')
        self.load_folder_button.clicked.connect(self.load_folder)
        self.clear_button = QPushButton('Clear Playlist')
        self.clear_button.clicked.connect(self.clear_playlist)
        
        # Layouts
        control_layout = QHBoxLayout()
        control_layout.addWidget(self.prev_button)
        control_layout.addWidget(self.play_button)
        control_layout.addWidget(self.stop_button)
        control_layout.addWidget(self.next_button)
        control_layout.addWidget(self.repeat_playlist_button)
        control_layout.addWidget(self.repeat_track_button)
        control_layout.addWidget(self.shuffle_button)
        
        load_layout = QHBoxLayout()
        load_layout.addWidget(self.load_button)
        load_layout.addWidget(self.load_folder_button)
        load_layout.addWidget(self.clear_button)
        
        time_layout = QHBoxLayout()
        time_layout.addWidget(self.current_time_label)
        time_layout.addWidget(self.time_slider)
        time_layout.addWidget(self.total_time_label)
        
        volume_layout = QHBoxLayout()
        volume_layout.addWidget(self.volume_label)
        volume_layout.addWidget(self.volume_slider)
        
        main_layout = QVBoxLayout()
        main_layout.addWidget(self.track_label)
        main_layout.addLayout(time_layout)
        main_layout.addLayout(control_layout)
        main_layout.addLayout(load_layout)
        main_layout.addWidget(self.playlist_widget)
        main_layout.addLayout(volume_layout)
        
        central_widget.setLayout(main_layout)
        
        # Устанавливаем громкость
        pygame.mixer.music.set_volume(self.volume_slider.value() / 100)

    def style_button(self, button, shape='circle'):
        if shape == 'circle':
            button.setFixedSize(50, 50)
            button.setStyleSheet('''
                QPushButton {
                    border-radius: 25px;
                    background-color: #ff6600;
                    font-size: 18px;
                    color: white;
                    border: none;
                }
                QPushButton:checked {
                    background-color: #ff3300;
                }
                QPushButton:hover {
                    background-color: #ff8833;
                }
            ''')
        elif shape == 'square':
            button.setFixedSize(50, 50)
            button.setStyleSheet('''
                QPushButton {
                    border-radius: 5px;
                    background-color: #ff6600;
                    font-size: 18px;
                    color: white;
                    border: none;
                }
                QPushButton:hover {
                    background-color: #ff8833;
                }
            ''')
        else:  # rounded
            button.setFixedSize(40, 40)
            button.setStyleSheet('''
                QPushButton {
                    border-radius: 10px;
                    background-color: #444;
                    font-size: 14px;
                    color: white;
                    border: none;
                }
                QPushButton:checked {
                    background-color: #ff6600;
                }
                QPushButton:hover {
                    background-color: #666;
                }
            ''')
        return None

    def show_context_menu(self, position):
        menu = QMenu()
        delete_action = QAction("Delete Track", self)
        delete_action.triggered.connect(self.delete_selected_track)
        menu.addAction(delete_action)
        menu.exec(self.playlist_widget.mapToGlobal(position))

    def delete_selected_track(self):
        current_row = self.playlist_widget.currentRow()
        if current_row >= 0 and current_row < len(self.playlist):
            if current_row == self.current_index:
                self.stop()
                self.current_index = -1
            
            self.playlist.pop(current_row)
            self.update_playlist_display()
            
            if self.current_index >= current_row and self.current_index > 0:
                self.current_index -= 1

    def load_files(self):
        files, _ = QFileDialog.getOpenFileNames(self, 'Open Audio Files', '', 'Audio Files (*.mp3 *.wav)')
        if files:
            self.playlist.extend(files)
            self.update_playlist_display()
            if self.current_index == -1:
                self.current_index = 0
                self.load_track(self.current_index)

    def load_folder(self):
        folder = QFileDialog.getExistingDirectory(self, 'Select Folder')
        if folder:
            files = [os.path.join(folder, f) for f in os.listdir(folder) if f.lower().endswith(('.mp3', '.wav'))]
            self.playlist.extend(sorted(files))
            self.update_playlist_display()
            if self.current_index == -1 and self.playlist:
                self.current_index = 0
                self.load_track(self.current_index)

    def clear_playlist(self):
        self.playlist.clear()
        self.playlist_widget.clear()
        self.current_index = -1
        self.stop()
        self.track_label.setText('No track loaded')

    def update_playlist_display(self):
        self.playlist_widget.clear()
        for i, track in enumerate(self.playlist):
            item = QListWidgetItem(os.path.basename(track))
            if i == self.current_index:
                item.setBackground(QColor('#ff6600'))
                item.setForeground(QColor('#ffffff'))
            self.playlist_widget.addItem(item)
        
        if self.current_index >= 0 and self.current_index < len(self.playlist):
            self.playlist_widget.setCurrentRow(self.current_index)

    def play_selected_track(self, item):
        index = self.playlist_widget.row(item)
        if 0 <= index < len(self.playlist):
            self.current_index = index
            self.load_track(self.current_index)

    def load_track(self, index):
        if 0 <= index < len(self.playlist):
            self.current_track = self.playlist[index]
            try:
                pygame.mixer.music.load(self.current_track)
                self.track_label.setText(os.path.basename(self.current_track))
                
                # Получаем длину трека
                if self.current_track.lower().endswith('.mp3'):
                    audio = MP3(self.current_track)
                elif self.current_track.lower().endswith('.wav'):
                    audio = WAVE(self.current_track)
                else:
                    audio = None
                
                self.track_length = audio.info.length if audio else 0
                self.total_time_label.setText(self.format_time(self.track_length))
                self.current_pos = 0
                self.time_slider.setValue(0)
                self.current_time_label.setText('00:00')
                
                self.update_playlist_display()
                
            except Exception as e:
                self.track_label.setText(f'Error loading file: {e}')

    def play(self):
        """Запуск воспроизведения с текущей позиции"""
        if hasattr(self, 'current_track') and self.current_track:
            pygame.mixer.music.play(start=self.current_pos)
            self.timer.start()
            self.is_paused = False
            self.play_button.setText('⏸')

    def play_pause(self):
        if not hasattr(self, 'current_track') or not self.current_track:
            if self.playlist:
                self.current_index = 0
                self.load_track(self.current_index)
            return

        if pygame.mixer.music.get_busy() and not self.is_paused:
            pygame.mixer.music.pause()
            self.is_paused = True
            self.play_button.setText('▶')
            self.timer.stop()
        else:
            if self.is_paused:
                pygame.mixer.music.unpause()
                self.is_paused = False
                self.play_button.setText('⏸')
                self.timer.start()
            else:
                self.play()

    def stop(self):
        pygame.mixer.music.stop()
        self.timer.stop()
        self.time_slider.setValue(0)
        self.current_time_label.setText('00:00')
        self.current_pos = 0
        self.play_button.setText('▶')
        self.is_paused = False

    def prev_track(self):
        if not self.playlist:
            return
            
        if self.shuffle_mode:
            self.current_index = random.randint(0, len(self.playlist) - 1)
        else:
            self.current_index = (self.current_index - 1) % len(self.playlist)
        
        self.load_track(self.current_index)
        self.play()

    def next_track(self):
        if not self.playlist:
            return
            
        if self.shuffle_mode:
            self.current_index = random.randint(0, len(self.playlist) - 1)
        else:
            self.current_index = (self.current_index + 1) % len(self.playlist)
        
        self.load_track(self.current_index)
        self.play()

    def toggle_repeat_playlist(self):
        self.repeat_playlist = self.repeat_playlist_button.isChecked()
        if self.repeat_playlist:
            self.repeat_track_button.setChecked(False)
            self.repeat_track = False

    def toggle_repeat_track(self):
        self.repeat_track = self.repeat_track_button.isChecked()
        if self.repeat_track:
            self.repeat_playlist_button.setChecked(False)
            self.repeat_playlist = False

    def toggle_shuffle(self):
        self.shuffle_mode = self.shuffle_button.isChecked()

    def slider_pressed(self):
        self.slider_being_moved = True
        self.timer.stop()

    def slider_released(self):
        self.slider_being_moved = False
        self.timer.start(100)

    def slider_moved(self, position):
        if hasattr(self, 'current_track') and self.current_track and self.track_length > 0:
            # ВЫЧИСЛЯЕМ НОВУЮ ПОЗИЦИЮ ДЛЯ ПЕРЕМОТКИ
            seek_pos = position / 1000.0 * self.track_length
            self.current_pos = seek_pos
            
            # ЕСЛИ ТРЕК ИГРАЕТ - ПЕРЕЗАПУСКАЕМ С НОВОЙ ПОЗИЦИИ
            if pygame.mixer.music.get_busy() or self.is_paused:
                was_playing = pygame.mixer.music.get_busy()
                pygame.mixer.music.stop()
                pygame.mixer.music.play(start=seek_pos)
                if not was_playing and self.is_paused:
                    pygame.mixer.music.pause()
                
            self.current_time_label.setText(self.format_time(seek_pos))

    def update_slider(self):
        if hasattr(self, 'current_track') and self.current_track and not self.slider_being_moved:
            if pygame.mixer.music.get_busy():
                # ОБНОВЛЯЕМ ТЕКУЩУЮ ПОЗИЦИЮ
                self.current_pos = pygame.mixer.music.get_pos() / 1000.0
                
                # Проверка окончания трека
                if self.current_pos >= self.track_length - 0.1:
                    self.track_ended()
                    return
                
                if self.track_length > 0:
                    slider_value = int(self.current_pos / self.track_length * 1000)
                    self.time_slider.blockSignals(True)
                    self.time_slider.setValue(slider_value)
                    self.time_slider.blockSignals(False)
                
                self.current_time_label.setText(self.format_time(self.current_pos))

    def track_ended(self):
        if self.repeat_track:
            self.current_pos = 0
            self.play()
        elif self.repeat_playlist or self.shuffle_mode or (self.current_index < len(self.playlist) - 1):
            self.next_track()
        else:
            self.stop()

    def change_volume(self):
        pygame.mixer.music.set_volume(self.volume_slider.value() / 100)

    def format_time(self, seconds):
        minutes = int(seconds // 60)
        seconds = int(seconds % 60)
        return f'{minutes:02}:{seconds:02}'

if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon('icon.ico'))
    player = QiwzyPlayer()
    player.show()
    sys.exit(app.exec())